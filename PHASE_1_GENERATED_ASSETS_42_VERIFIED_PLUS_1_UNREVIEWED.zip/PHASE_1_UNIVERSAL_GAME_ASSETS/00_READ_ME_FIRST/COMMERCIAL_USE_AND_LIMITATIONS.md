# Commercial use and limitations

The accepted assets are marked **COMMERCIAL-GAME-ELIGIBLE** based on the public
terms and original-input audit recorded in `../10_MANIFESTS_AND_LICENSE_EVIDENCE/rights_evidence.json`.
This is an evidence-based eligibility assessment, not a legal guarantee.

All geometry, layouts, synthesis designs and resulting sound samples were
created for this task. For the 42 accepted assets, no external meshes, textures, sound recordings, music,
fonts, voices, character likenesses or proprietary game files were imported.
Public game references were used to study general design principles only.
Reference images are excluded from this archive.

The creation service's [output terms](https://openai.com/policies/services-agreement/)
assign its output rights to the customer to the extent permitted by law.
The [software-output guidance](https://www.gnu.org/licenses/gpl-faq.en.html#GPLOutput)
supports treating original generated data separately from processing software.
The per-method evidence ledger records the relevant processing licenses and
the limits of source access, including one official policy reviewed through
its indexed excerpt rather than an accessible full page.

**Shipping in a commercial game:** supported under the assessed public terms,
provided the recipient has lawful access to the creation service and complies
with the applicable agreement and law. No asset-level attribution requirement
was identified for these original outputs. Processing libraries are not
distributed in this archive, so their software redistribution notices do not
become an asset credit requirement.

**Reselling a standalone stock pack:** not certified. Output assignment does
not establish exclusivity, protectability in every jurisdiction, or compliance
with any particular stock marketplace's AI-content rules. No claim of exclusive
ownership, registered copyright, indemnity, or universal clearance is made.

**Known uncertainty:** the user's private account contract and jurisdiction were
not inspected. The exact text-generation model's internal training data and
weights were not available for audit; no third-party model weights were used.
Originality review covers the pack and the researched examples, not every
existing work worldwide. Automated similarity scores do not establish legal
non-infringement. Review was performed by the assistant and deterministic
checks, with no independent lawyer, human art director or human listening panel.
