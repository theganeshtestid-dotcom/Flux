# Integration guide

## 3D models
Use `model.glb` for the optimized static model. `model_editable.glb` preserves
named component meshes for editing and future articulation. These two files
represent one identity. Materials are embedded solid metallic/roughness PBR;
no missing texture maps are required. Thin sail/panel surfaces are intentional.
No skeleton, skin weights, animation clips or hidden dependencies are claimed.

Units are metres. Export files use right-handed Y-up coordinates; the design
records use Z-up. A design point `(x,y,z)` maps to export `(x,z,-y)`. The model's
lowest point is at height zero, with the world-origin pivot centred horizontally.
The flying courier is a static mesh; place it above the ground in your game.
The editable version is provided for later rigging, not as a ready-made rig.

## Levels and maps
`level.glb` combines static scenery while retaining named gate, switch and exit
parts. `level_editable.glb` retains the full component hierarchy. `layout.json`
contains the navigation graph, entrance/exit, switch and gate condition.
`walkable_polygons.json` defines conservative room and corridor polygons.
The backdrop and decorative scenery are nonwalkable. The map alone is not a
complete game: connect movement, gate colliders and event logic in your project.

Use an actor radius of approximately 0.20m, height 0.90m and 0.05m step tolerance.
Room foot height is 0.30m; path slabs top out at 0.295m. A switch can be activated
within 0.9m; do not route the actor directly through its central pedestal.
Disable the named locked barrier and its collider when the switch activates.
Some maps deliberately offer an unlocked longer route around the gated shortcut.
The QA report explicitly records whether the exit is reachable before switching.

For `map_topdown.png`, `px=(x+10)*76.8`, `py=(10-y)*76.8` on the 1536px canvas.
Node image anchors are supplied. Draw level numbers, progress, locks and UI in
your game; these have not been baked into the art. Navigation metadata uses
authored graph edges: it is not an automatically generated navigation mesh.

## Sounds
`master.wav` is 48kHz mono, 24-bit PCM. `game.ogg` is the compressed alternative.
They count as one cue. Trigger them as event one-shots and disable looping.
Use the WAV for sample-accurate timing or import/transcoding. Compressed playback
may have codec-specific timing differences. Adjust in-game gain to the mix;
masters peak at approximately -3dBFS, with different natural RMS levels.
Rate-limit repeated UI/mechanism triggers so tails do not stack excessively.
No music, ambience, speech, recordings or voice clones are included.

## Performance and transparency
Use the optimized geometry for runtime; the editable source contains many more
objects. `reopen_validation.json` records estimated material draw calls, and
`technical_validation.json` records the actual triangle count. Level budgets
are larger than individual models: select only visible regions and profile on
the target device. No universal frame-rate guarantee is made.
PNG previews use genuine alpha, straight RGBA and no baked checkerboard.
Previews are supporting art, not substitutes for the mesh or navigation data.
