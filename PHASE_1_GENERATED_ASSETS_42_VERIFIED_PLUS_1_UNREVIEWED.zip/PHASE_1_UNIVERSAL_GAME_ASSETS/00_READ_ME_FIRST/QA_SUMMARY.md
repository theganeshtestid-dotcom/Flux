# QA summary

42 accepted identities: 12 models, 10 levels/maps, 20 gameplay SFX. One earlier
character candidate is separately marked REVIEW REQUIRED and not counted.
The original 4,000 target remains incomplete: 3,958 accepted identities short.
Other categories were deferred by the user's updated instructions.

- All 44 runtime/editable mesh files reopened in fresh scenes after cleanup.
- Every primary mesh has nonempty 3D geometry, finite coordinates and normals,
  embedded materials, valid indices and zero collapsed triangles after repair.
- Every level has an entrance-to-switch route with the gate closed, a route
  from switch to exit after unlocking, and connectivity to every room.
- No unconnected path-edge crossings were detected. Walkable polygons and
  top-down anchors are supplied. Gates are data/geometry, not implemented game code.
- All 20 lossless masters and compressed alternatives decode correctly.
  Masters peak near -3dBFS, have nontrivial content and clean start/end samples.
- All 190 sound pairs were screened. Highest lag-tolerant normalized waveform
  correlation: 0.5047; no pair crossed the documented near-duplicate thresholds.
- Primary file hashes and canonical geometry/layout fingerprints are distinct.
- Model silhouettes and map compositions were inspected in contact sheets and
  enlarged views; two structural details and the initial sparse map were revised.

These checks establish the documented technical properties and the assistant's
art assessment, not independent human studio certification. Acoustic analysis
was used instead of claiming a human listening panel. No universal performance,
copyright exclusivity or legal-clearance guarantee is made. Material draw counts
and triangle budgets are recorded per file for target-device profiling.

The release ZIP is checked for CRC integrity, manifest path resolution and exact
checksums by the packaging script. See `archive_validation.json` alongside it
in the release workspace for the final ZIP checksum; the internal file index is
`../10_MANIFESTS_AND_LICENSE_EVIDENCE/file_checksums.json`.
