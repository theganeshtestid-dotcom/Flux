# FLUX design proposal — approval required before Flutter implementation

Read `index.html` for 12 visual screen mockups. All numbers are illustrative, not real saved records. This is a design artifact, not a working application.

## Brand and layout

Use the supplied infinity logo unchanged. Revised per the supplied FLUX V3 Screens reference: primary orange #F87115; light background #F4F3EE with white surfaces; dark background #0F1014 with #191C23 surfaces and #262A33 secondary surfaces. Preserve the logo’s blue, orange, and green in the original mark. Semantic green identifies completion. Use dark variants for text, text labels alongside color, white cards, pale neutral backgrounds, rounded corners, and 48 dp minimum touch targets. Flutter typography proposal: bundled Roboto or Android system sans; no downloaded fonts. Navigation labels stay visible. Screen-reader labels, large text and reduced motion will be implementation checks.

Exactly four tabs: Home, Academics, Study, Profile/Settings. Settings appear only in the fourth tab. Exactly four Quick Add choices: Subject, Assignment, Study Session, Exam. Attendance belongs to class occurrences, never Quick Add.

## User flows

```mermaid
flowchart TD
  Launch[Launch / local database] --> Check{Database state}
  Check -->|Missing| Empty[Create empty database / Home guidance]
  Check -->|Healthy| Home[Home / today's classes]
  Check -->|Corrupt| Recover[Preserve damaged file if practical / fresh database / honest notice]
  Recover --> Empty
  Empty --> Subject[Add subject]
  Subject --> Class[Subject detail / add weekly class times]
  Class --> Validate{Valid time range?}
  Validate -->|No| Error[Inline error / keep entered values]
  Validate -->|Yes| Overlap{Overlapping class?}
  Overlap -->|Yes| Warn[Warn / edit or explicitly continue]
  Overlap -->|No| Home
  Warn --> Home
  Home --> Occurrence[Select dated class occurrence]
  Occurrence --> Mark[Present or Absent / correct existing mark]
  Mark --> Totals[Recalculate recorded attendance everywhere]
  Home --> Quick[Quick Add sheet]
  Quick --> Subject
  Quick --> Assignment[Assignment form / save]
  Quick --> Session[Manual study session / positive duration / save]
  Quick --> Exam[Exam form / save]
  Assignment --> Tasks[Upcoming / Due Today / Overdue / Completed]
  Exam --> Permission[If enabling reminder: explain benefit / request Android permission]
  Permission -->|Denied| Saved[Keep item saved / reminder unavailable]
  Permission -->|Granted| Notify[Schedule local reminder]
  Session --> Study[Study / history / totals]
  Study --> Recap[Weekly Recap / explicit week range]
  Recap --> Preview[Progress card preview / no private notes]
  Preview --> Generate{Image generated?}
  Generate -->|No| Retry[Nonblocking error / retry]
  Generate -->|Yes| Share[Android share sheet]
  Share --> Return[Return gracefully on share or cancel]
  Home --> Academics[Academics / subjects, timetable, attendance, tasks, exams]
  Home --> Profile[Profile / notification state, badges, logs, app info]
  Profile --> Logs[View local errors / confirm clear / empty state]
```

## Remaining screen specifications

- Subject form: required name; optional teacher and room. Subject detail contains weekly classes and links to related records. Class form: weekday, start/end, optional room override. End ≤ start blocks saving. Overlap produces a warning with explicit choices.
- Assignment: title and due date required; optional subject, description, time and reminder. List supports four exact statuses, detail/edit, complete, and confirmed delete. Completion overrides overdue status.
- Exam: title and date required; optional subject, time, room, notes and reminder. Detail supports edit/delete. Editing time replaces its notification; deleting cancels it.
- All forms preserve input on errors and warn before discarding edits. All destructive actions require confirmation. Deleting a subject or class must explain historical attendance retention; retain understandable historical labels.
- Badges detail shows exactly First Subject (first subject), Attendance Starter (5 distinct recorded occurrences), Study Starter (first valid session), Task Completer (3 completed assignments), Consistent Student (≥75% across ≥10 recorded occurrences). Awards persist and are never revoked. Display x/5.
- Notification preferences show global enablement and actual Android permission separately. Request permission only after contextual explanation when a user enables reminders; denial never prevents saving. Delivery is best-effort.
- Every primary list has an actionable empty state. With no recorded attendance, display “No records yet,” not a misleading percentage. Weekly Recap explains each missing data category.
- Recovery notice is one-time, honest about unrecovered data. Error-log writes must never cause a crash. Progress image failures preserve the screen; share cancellation returns normally.

## Calculation and period rules

Attendance = present / (present + absent); unmarked occurrences excluded. Study = sum of valid saved durations. Home attendance is overall, Home study and Study total are this week, Recap and card attendance/study are the selected week; badges are lifetime. Weeks proposed Monday 00:00 through next Monday exclusive in device local time. Current week labelled “Week so far.” Assignment status depends on local calendar date and completion, not optional due time.

## Proposed v1 decisions

System-following appearance by default, with explicit Light and Dark choices in Profile → Appearance; Monday–Sunday weeks, manual study entry; defer optional running timer. No login, cloud, backup/restore, app lock, finance, analytics, extra recap types or INTERNET permission. The user approved the revised colors and authorized Flutter implementation; those theme colors are fixed.

## Repository review

Reviewed the README and purpose of each supplied repository (not a full security or code audit):

- https://github.com/garrytan/gstack — development skills spanning product framing, design review, engineering review and QA; Codex support described as experimental. Useful process reference; not a Flutter component library.
- https://github.com/obra/superpowers — structured design approval, planning, implementation and verification workflow. Useful process reference; not an app template.
- https://github.com/DietrichGebert/ponytail — reuse existing components, keep implementation focused, review correctness and risky paths. Useful review reference; not a UI kit.

Repositories downloaded under /workspace/research for read-only review; no installers or hooks executed and no third-party code integrated. The PRD controls product requirements; the supplied logo controls branding. No ZIP was present among attachments. Review of that ZIP remains pending attachment.

## V3 visual reference update

The user approved the initial direction and requested reference-style colors plus both light and dark modes. `index.html` now offers working Light, Dark, and System preview controls; preview selection persists when browser storage is available. App appearance preference will be stored locally during Flutter implementation. Updated boards: `flux-ui-light.png` and `flux-ui-dark.png`. The prior `flux-ui-board.png` and `v1-logo-palette.html` are the original proposal.

The 11-page V3 reference was text-extracted and its first page visually inspected for palette and surface treatment. It includes incompatible product examples (eight monthly badges, monthly recap, safe misses, study goals, migration content). These are not adopted: the original PRD still governs five lifetime badges, one Weekly Recap and no invented migration/deletion flow. Only its visual theme and the requested Appearance preference are adopted.

## Implementation authorization

The user approved the revised light/dark theme and authorized app development, allowing layout changes while preserving the approved palette. Flutter source is now under `lib/` and `android/`. See `../README.md` for verification status. ZIP component review remains pending upload.
